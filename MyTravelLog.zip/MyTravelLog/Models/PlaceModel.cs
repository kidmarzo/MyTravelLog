namespace MyTravelLog.Models;

/// <summary>
/// Represents a single travel place entry logged by the user.
/// All properties are plain CLR properties; change notification is handled
/// in the ViewModel layer using CommunityToolkit.Mvvm.
/// </summary>
public class PlaceModel
{
    /// <summary>Unique identifier for the place.</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>User-supplied name for the place (e.g. "Eiffel Tower").</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>User's notes about the visit.</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// Full file-system path to the captured photo stored in the app cache.
    /// Null or empty when no photo was taken.
    /// </summary>
    public string? PhotoPath { get; set; }

    /// <summary>GPS latitude in decimal degrees.</summary>
    public double Latitude { get; set; }

    /// <summary>GPS longitude in decimal degrees.</summary>
    public double Longitude { get; set; }

    /// <summary>Human-readable address obtained via reverse geocoding.</summary>
    public string Address { get; set; } = "Address not available";

    /// <summary>UTC timestamp when the entry was created.</summary>
    public DateTime DateAdded { get; set; } = DateTime.UtcNow;

    /// <summary>Formatted date string used in the UI.</summary>
    public string FormattedDate => DateAdded.ToLocalTime().ToString("dd MMM yyyy, HH:mm");

    /// <summary>
    /// Truncated address for list views – keeps CollectionView items concise.
    /// </summary>
    public string ShortAddress =>
        Address.Length > 50 ? Address[..47] + "…" : Address;

    /// <summary>True when a photo has been captured for this place.</summary>
    public bool HasPhoto => !string.IsNullOrEmpty(PhotoPath);

    /// <summary>
    /// Returns a formatted coordinate string for display purposes.
    /// </summary>
    public string CoordinatesDisplay =>
        $"{Latitude:F5}°, {Longitude:F5}°";
}
