using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MyTravelLog.Models;
using MyTravelLog.Services;

namespace MyTravelLog.ViewModels;

/// <summary>
/// ViewModel for the Places List page.
/// Exposes the shared ObservableCollection from PlaceDataService and
/// provides delete and navigation commands.
/// </summary>
public partial class PlacesListViewModel : BaseViewModel
{
    private readonly PlaceDataService _placeDataService;

    public PlacesListViewModel(PlaceDataService placeDataService)
    {
        _placeDataService = placeDataService;
        Title = "My Places";
    }

    /// <summary>
    /// Bound to the CollectionView's ItemsSource.
    /// Automatically updates the UI when items are added/removed.
    /// </summary>
    public ObservableCollection<PlaceModel> Places => _placeDataService.Places;

    /// <summary>True when the collection is empty – shows the empty state view.</summary>
    public bool IsEmpty => Places.Count == 0;

    [ObservableProperty] private PlaceModel? _selectedPlace;

    // ── Navigation ───────────────────────────────────────────────────────

    /// <summary>Navigates to the detail view for the tapped place.</summary>
    [RelayCommand]
    private async Task SelectPlace(PlaceModel place)
    {
        if (place is null) return;

        // Pass the place Id as a query parameter
        var parameters = new Dictionary<string, object> { ["PlaceId"] = place.Id.ToString() };
        await Shell.Current.GoToAsync(nameof(Views.PlaceDetailPage), parameters);
    }

    /// <summary>Navigates to the add-place form.</summary>
    [RelayCommand]
    private async Task AddNewPlace()
    {
        await Shell.Current.GoToAsync(nameof(Views.AddPlacePage));
    }

    // ── Delete ───────────────────────────────────────────────────────────

    /// <summary>
    /// Asks for confirmation, then removes the selected place.
    /// Triggered by the swipe-to-delete action in the CollectionView.
    /// </summary>
    [RelayCommand]
    private async Task DeletePlace(PlaceModel place)
    {
        if (place is null) return;

        bool confirmed = await Shell.Current.DisplayAlert(
            "Delete Place",
            $"Are you sure you want to delete '{place.Name}'?",
            "Delete", "Cancel");

        if (!confirmed) return;

        try
        {
            // Delete associated photo from cache to free storage
            if (!string.IsNullOrEmpty(place.PhotoPath) && File.Exists(place.PhotoPath))
                File.Delete(place.PhotoPath);

            _placeDataService.RemovePlace(place);
            OnPropertyChanged(nameof(IsEmpty));
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert(
                "Delete Error",
                $"Could not delete place: {ex.Message}",
                "OK");
        }
    }

    /// <summary>Refresh derived properties when the page appears.</summary>
    public void OnAppearing() => OnPropertyChanged(nameof(IsEmpty));
}
