using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MyTravelLog.Models;
using MyTravelLog.Services;

namespace MyTravelLog.ViewModels;

/// <summary>
/// ViewModel for the Place Detail page.
/// Receives the place Id via Shell query parameter, loads the model,
/// and exposes Text-to-Speech and Share commands.
/// </summary>
[QueryProperty(nameof(PlaceId), "PlaceId")]
public partial class PlaceDetailViewModel : BaseViewModel
{
    private readonly PlaceDataService    _placeDataService;
    private readonly TextToSpeechService _ttsService;
    private readonly HapticService       _hapticService;

    public PlaceDetailViewModel(
        PlaceDataService    placeDataService,
        TextToSpeechService ttsService,
        HapticService       hapticService)
    {
        _placeDataService = placeDataService;
        _ttsService       = ttsService;
        _hapticService    = hapticService;

        Title = "Place Details";
    }

    // ── Query parameter ──────────────────────────────────────────────────

    /// <summary>
    /// Set by Shell navigation; triggers loading the correct place.
    /// </summary>
    [ObservableProperty]
    private string _placeId = string.Empty;

    partial void OnPlaceIdChanged(string value)
    {
        if (Guid.TryParse(value, out var id))
            CurrentPlace = _placeDataService.GetById(id);
    }

    // ── Bound data ───────────────────────────────────────────────────────

    [ObservableProperty] private PlaceModel? _currentPlace;

    [ObservableProperty] private bool _isSpeaking;

    // ── Text-to-Speech command ───────────────────────────────────────────

    /// <summary>
    /// Reads the place description aloud using the device TTS engine.
    /// Hardware feature: Text-to-Speech.
    /// </summary>
    [RelayCommand]
    private async Task ReadAloud()
    {
        if (CurrentPlace is null) return;

        if (IsSpeaking)
        {
            _ttsService.Stop();
            IsSpeaking = false;
            return;
        }

        IsSpeaking = true;
        try
        {
            string textToRead =
                $"Place: {CurrentPlace.Name}. " +
                $"Located at {CurrentPlace.Address}. " +
                $"Description: {CurrentPlace.Description}. " +
                $"Visited on {CurrentPlace.FormattedDate}.";

            await _ttsService.SpeakAsync(textToRead);
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert(
                "Speech Error",
                $"Could not read text: {ex.Message}",
                "OK");
        }
        finally
        {
            IsSpeaking = false;
        }
    }

    // ── Share command ────────────────────────────────────────────────────

    /// <summary>
    /// Shares place details using the native share sheet.
    /// Also triggers haptic feedback as a confirmation cue.
    /// </summary>
    [RelayCommand]
    private async Task SharePlace()
    {
        if (CurrentPlace is null) return;

        try
        {
            _hapticService.Vibrate(150);

            await Share.Default.RequestAsync(new ShareTextRequest
            {
                Title   = $"My visit to {CurrentPlace.Name}",
                Text    = $"I visited {CurrentPlace.Name} on {CurrentPlace.FormattedDate}.\n" +
                          $"Location: {CurrentPlace.Address}\n\n" +
                          $"{CurrentPlace.Description}"
            });
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert(
                "Share Error",
                $"Could not share: {ex.Message}",
                "OK");
        }
    }

    // ── Back navigation ──────────────────────────────────────────────────

    [RelayCommand]
    private async Task GoBack()
    {
        _ttsService.Stop();
        await Shell.Current.GoToAsync("..");
    }
}
