using MyTravelLog.Services;

namespace MyTravelLog;

/// <summary>
/// Root application class.
/// Applies the saved theme (light/dark) on every cold start so the user's
/// preference is respected before any page is rendered.
/// </summary>
public partial class App : Application
{
    private readonly SettingsService _settingsService;

    public App(SettingsService settingsService)
    {
        InitializeComponent();

        _settingsService = settingsService;

        // Apply persisted theme immediately
        ApplyTheme(_settingsService.IsDarkMode);

        MainPage = new AppShell();
    }

    /// <summary>
    /// Switches the application between light and dark themes.
    /// Called on startup and whenever the user toggles the setting.
    /// </summary>
    public void ApplyTheme(bool isDark)
    {
        UserAppTheme = isDark ? AppTheme.Dark : AppTheme.Light;
    }
}
