using MyTravelLog.ViewModels;

namespace MyTravelLog.Views;

/// <summary>
/// Code-behind for PlacesListPage.
/// Refreshes the empty-state visibility each time the page appears,
/// since the user may have added or deleted a place on another page.
/// </summary>
public partial class PlacesListPage : ContentPage
{
    private readonly PlacesListViewModel _viewModel;

    public PlacesListPage(PlacesListViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        BindingContext = _viewModel;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _viewModel.OnAppearing();
    }
}
