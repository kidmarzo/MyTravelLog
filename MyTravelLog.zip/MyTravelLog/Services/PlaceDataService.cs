using System.Collections.ObjectModel;
using MyTravelLog.Models;

namespace MyTravelLog.Services;

/// <summary>
/// Singleton in-memory data store for all saved places.
/// Uses ObservableCollection so bound CollectionViews update automatically
/// when items are added or removed.
/// </summary>
public class PlaceDataService
{
    /// <summary>
    /// The master list of all saved travel places.
    /// ViewModels bind directly to this collection.
    /// </summary>
    public ObservableCollection<PlaceModel> Places { get; } = new();

    /// <summary>
    /// Adds a new place to the collection.
    /// </summary>
    public void AddPlace(PlaceModel place)
    {
        ArgumentNullException.ThrowIfNull(place);
        Places.Insert(0, place); // Newest first
    }

    /// <summary>
    /// Removes a place from the collection by reference.
    /// Returns true if the item was found and removed.
    /// </summary>
    public bool RemovePlace(PlaceModel place)
    {
        ArgumentNullException.ThrowIfNull(place);
        return Places.Remove(place);
    }

    /// <summary>
    /// Finds a place by its unique identifier.
    /// Returns null when not found.
    /// </summary>
    public PlaceModel? GetById(Guid id)
        => Places.FirstOrDefault(p => p.Id == id);
}
